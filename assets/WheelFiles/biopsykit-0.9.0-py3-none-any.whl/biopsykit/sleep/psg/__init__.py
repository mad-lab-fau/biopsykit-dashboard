"""Module containing functions to process polysomnography (PSG) data."""
